int a;
int d;
a=1000;

if(a>50)
{
  int b;
  b=121;
  d=d+100;
}
else
 {
   d=d-100;
 }  
